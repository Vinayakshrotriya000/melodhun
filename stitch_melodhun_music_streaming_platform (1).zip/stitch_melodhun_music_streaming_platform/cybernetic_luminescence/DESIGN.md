---
name: Cybernetic Luminescence
colors:
  surface: '#13121c'
  surface-dim: '#13121c'
  surface-bright: '#393843'
  surface-container-lowest: '#0d0d17'
  surface-container-low: '#1b1b24'
  surface-container: '#1f1f29'
  surface-container-high: '#292933'
  surface-container-highest: '#34343e'
  on-surface: '#e4e1ef'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e4e1ef'
  inverse-on-surface: '#302f3a'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#ddb7ff'
  on-tertiary: '#490080'
  tertiary-container: '#b76dff'
  on-tertiary-container: '#400071'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#f0dbff'
  tertiary-fixed-dim: '#ddb7ff'
  on-tertiary-fixed: '#2c0051'
  on-tertiary-fixed-variant: '#6900b3'
  background: '#13121c'
  on-background: '#e4e1ef'
  surface-variant: '#34343e'
typography:
  display-hero:
    fontFamily: Sora
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Sora
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Sora
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Sora
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-mobile: 1rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies the sensory intensity of next-generation digital acoustics. Positioned at the intersection of high-fidelity audio engineering and speculative cyber-aesthetics, it serves audiophiles, electronic music enthusiasts, producers, and digital-native listeners who view music consumption as an immersive, spatial experience.

The visual narrative merges **Glassmorphism** with **Futuristic Cybernetic Minimalism**:
- **Atmospheric Depth:** Deep abyssal canvases punctuated by spectral light sources that react dynamically to frequency and rhythm.
- **Precision Optics:** Frosted translucent surfaces mimicking polarized glass displays, accented with laser-thin luminous borders and bioluminescent glow falloffs.
- **Kinetic Resonance:** Interfaces feel reactive and alive, utilizing micro-luminescence and fluid audio visualizers that elevate track browsing into a sonic journey.

## Colors

The color architecture is built strictly for high-contrast dark environments, preserving battery efficiency on OLED displays while maximizing luminescence for interactive signals.

### Palette Architecture
- **Midnight Foundations (Neutral Base):**
  - Canvas Deep: `#080811` (Pure abyssal base for maximum dynamic range)
  - Surface Mid: `#0D0E1A` (Layer 1 containment, panels, and docks)
  - Surface Elevated: `#131528` (Cards, drawers, floating sheets)
  - Border Glass: `rgba(255, 255, 255, 0.08)` to `rgba(139, 92, 246, 0.25)` for active states
- **Sonic Spectrum (Primary & Secondary Accents):**
  - **Electric Purple (`#8B5CF6`):** The primary brand signature. Represents acoustic power, active play states, and high-frequency energy.
  - **Vibrant Violet (`#A855F7`):** Tertiary gradient complement, used to build chromatic shifts across progress scrubbers and visualizers.
  - **Neon Cyan / Cyber Teal (`#06B6D4` / `#22D3EE`):** Secondary accent reserved for spatial audio tags, live streams, lossless audio badges, and scrub heads.
- **Functional Semantics:**
  - Success/Live: `#10B981` (Tuned down with cyan bias)
  - Alert/Clipping: `#F43F5E` (Laser crimson)
  - Text High-Emphasis: `#F8FAFC` (96% luminance)
  - Text Muted: `#94A3B8` (Mid-tone slate for secondary metadata and timestamps)

## Typography

The typographic hierarchy establishes distinct roles across three typeface engines:

1. **Sora (Headlines & Identity):** Delivers a bold, geometric, futuristic presence for artist names, album titles, and immersive hero copy.
2. **Plus Jakarta Sans (Body & Information Architecture):** Provides exceptional readability at small-to-medium optical sizes, counterbalancing geometric headlines with humanist clarity.
3. **Space Grotesk (Labels, Timecodes & Metrics):** Infuses a technical audio-rack character. Used for durations, bitrates (e.g., `FLAC 24-bit/96kHz`), audio channel badges, and UI controls.

## Layout & Spacing

The structural layout utilizes a high-density, mobile-first responsive architecture designed around thumbsweep accessibility and persistent playback zones:

- **Mobile Viewports (<768px):** Single-column layout with 4-column sub-grids for album feeds. Persistent bottom mini-player dock positioned 80px above base system controls. Canvas margins maintain a tight `1rem` buffer.
- **Tablet / Mid-Viewports (768px - 1024px):** 8-column layout. Split interface with persistent navigation sidebar and multi-tier grid feeds.
- **Desktop / Ultra-Wide (>1024px):** 12-column layout with fixed navigation rail (left), adaptive central discovery feed, and dynamic contextual drawer (right) for queued tracks, real-time lyrics, and visualizer telemetry.
- **Vertical Spacing Scale:** Rhythm strictly adheres to an 8pt baseline (`space-xs` = 4px, `space-sm` = 8px, `space-md` = 16px, `space-lg` = 24px, `space-xl` = 40px). Component padding preserves a minimum touch-target area of 44x44px across all audio interactions.

## Elevation & Depth

Spatial elevation relies on **multi-layer glassmorphism** and **diffused chromatic radiance** rather than traditional drop shadows:

- **Level 0 (Floor Canvas):** Flat `#080811` background, optionally layered with dynamic radial mesh gradients tied to album artwork dominant colors at 15% opacity.
- **Level 1 (Submerged Glass):** Background `rgba(13, 14, 26, 0.65)`, backdrop filter blur `16px`, border `1px solid rgba(255, 255, 255, 0.05)`. Used for horizontal track carousels and playlist rows.
- **Level 2 (Floating Glass / Active Cards):** Background `rgba(19, 21, 40, 0.75)`, backdrop filter blur `24px`, border `1px solid rgba(139, 92, 246, 0.20)`. Subtle edge rim lighting.
- **Level 3 (Modal & Full Audio Player Sheet):** Background `rgba(13, 14, 26, 0.90)`, backdrop filter blur `32px`, top border highlight `1px solid rgba(34, 211, 238, 0.35)`.
- **Neon Radiance (Bioluminescence):**
  - Active Playback Elements: `box-shadow: 0 0 24px -4px rgba(139, 92, 246, 0.45), 0 0 10px 0 rgba(6, 182, 212, 0.30)`.
  - Scrub Head Glow: Radial aura extending 8px beyond the thumb target.

## Shapes

The design system incorporates smooth, aerodynamic radii:
- Standard interactive elements (inputs, cards, playlist items) implement a `0.5rem` (8px) corner radius.
- Larger spatial surfaces, album sleeves, and floating bottom docks use `rounded-lg` (`1rem` / 16px) or `rounded-xl` (`1.5rem` / 24px) for organic tactility.
- Micro-badges, audio state pills, and primary play buttons transition into complete cylindrical pills (`rounded-full` / 9999px) to communicate instantaneous action and momentum.

## Components

### Buttons & Interactive Triggers
- **Master Play/Pause Button:** Circular floating trigger (`56px` to `64px` on mobile), layered with an electric purple-to-violet linear gradient (`135deg, #8B5CF6, #A855F7`), encased in an outer cyan halo glow on active playback.
- **Secondary Actions:** Frosted glass pill buttons with translucent white borders (`rgba(255, 255, 255, 0.12)`) and `Space Grotesk` uppercase text. On hover/active, the border transitions to neon cyan with micro-fill glow.

### Interactive Sliders & Scrubbers
- **Track Progress Bar:** 4px base rail in `rgba(255, 255, 255, 0.1)`. Active fill utilizes a bidirectional gradient (`#8B5CF6` transitioning into `#22D3EE`). 
- **Scrub Thumb:** 12px circular node with a cyan glow pulse. Expands to 16px during interaction.
- **Waveform Seekers:** Dynamic equalizer amplitude bars that double as scrubber tracks; past segments highlight in violet, future segments rest at 20% opacity.

### Audio Cards & Feed Tiles
- **Album & Track Cards:** Nested inside Level 1 or Level 2 glass surfaces. Features an edge-to-edge album thumbnail with an integrated 12px radius, metadata stacked cleanly in `Sora` (title) and `Plus Jakarta Sans` (artist), accompanied by high-res codec indicators (`Hi-Res`, `Lossless`, `Dolby Atmos`) rendered in `label-sm`.
- **Hover/Touch States:** Subtle vertical shift (-2px) accompanied by an increase in border luminescence from neutral glass to electric violet.

### Chips, Tags & Badges
- Compact pill-shaped modules (`height: 28px`) rendered in `rgba(13, 14, 26, 0.8)` with a 1px frosted outline. 
- Active category/genre chips trigger a solid neon cyan under-glow with white typography.

### Soundwave Visualizers & Dynamic Status
- Equalizer animators constructed of 3 to 5 vertical frequency bars with variable heights (`8px` to `24px`), fluctuating smoothly using CSS transforms. Tinted in `#22D3EE` to signal current playback stream.

### Form Inputs & Search Fields
- Fully translucent search bar with Level 1 glass, pre-fixed with a low-opacity cyan optical search icon. 
- Focus state activates an animated gradient border border (`#8B5CF6` to `#06B6D4`) without heavy background shifts, preserving canvas purity.